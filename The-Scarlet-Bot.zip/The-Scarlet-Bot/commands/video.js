module.exports = {
  name: "video",
  execute(msg, args) {
    msg.reply("🎥 Here's your video!", { video: "https://example.com/sample-video.mp4" });
  }
};