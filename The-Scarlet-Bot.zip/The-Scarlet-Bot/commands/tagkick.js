module.exports = {
  name: "tagkick",
  execute(msg, args) {
    if (!msg.mentions || msg.mentions.length === 0) {
      msg.reply("Please tag someone to kick.");
      return;
    }
    msg.reply(\`User \${msg.mentions[0].name} has been kicked! 🚫\`);
  }
};