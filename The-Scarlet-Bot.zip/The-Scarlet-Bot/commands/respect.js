module.exports = {
  name: "respect",
  execute(msg, args) {
    msg.reply("🙏 Respect to you, friend!");
  }
};