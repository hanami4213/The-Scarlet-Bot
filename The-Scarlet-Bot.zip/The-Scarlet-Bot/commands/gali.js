module.exports = {
  name: "gali",
  execute(msg, args) {
    msg.reply("😡 Hey! Watch your language!");
  }
};